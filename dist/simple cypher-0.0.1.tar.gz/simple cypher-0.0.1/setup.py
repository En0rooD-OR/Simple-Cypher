from setuptools import setup

setup(
    name="Simple Cypher",
    description="Cesar and Vignére code cipher and decryptor",
    version="0.0.1",
    author="EnrooD-OR",
    url="https://github.com/En0rooD-OR/Simple-Cypher",
    packages= ["SCypher"],
)

"""
   youtube="https://www.youtube.com/@en0roodOr",
    facebook="https://www.facebook.com/EnorooD",
    github="https://github.com/En0rooD-OR",
"""